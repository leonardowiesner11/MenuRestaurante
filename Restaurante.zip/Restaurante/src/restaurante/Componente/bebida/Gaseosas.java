/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante.Componente.bebida;

/**
 *
 * @author Estudiantes
 */
public abstract class Gaseosas extends Bebida{
    @Override
    public abstract String guardar();
    public String CocaCola; 
    public String Pepsi;
    public String Quatro;
    public String SevenUp;
    
    public Gaseosas (String CocaCola, String Pepsi, String Quatro, String SevenUp){
     this.CocaCola=CocaCola;
     this.Pepsi=Pepsi;
     this.Quatro=Quatro;
     this.SevenUp=SevenUp;
             
    }
    
    public String mostrarGaseosas(){
     return "Gaseosas disponibles: "+CocaCola+Pepsi+Quatro+SevenUp;
    }
    }

