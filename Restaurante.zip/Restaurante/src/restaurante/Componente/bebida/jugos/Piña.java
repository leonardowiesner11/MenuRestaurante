/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante.Componente.bebida.jugos;
import restaurante.Componente.bebida.*;
/**
 *
 * @author Estudiantes
 */
public class Piña extends Jugos{
    @Override
    public String guardar(){
        return"n    Pepsi";
    }
}    

