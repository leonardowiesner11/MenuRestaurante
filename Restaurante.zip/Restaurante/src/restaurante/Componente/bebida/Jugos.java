
package restaurante.Componente.bebida;


public abstract class Jugos extends Bebida{
    @Override
    public abstract String guardar();
    public String mora;
    public String fresa;
    public String mango;
    public String piña;
    
    public Jugos (String mora, String fresa, String mango, String piña){
     this.mora=mora;
     this.fresa=fresa;
     this.mango=mango;
     this.piña=piña;
             
    }
    
    public String mostrarGaseosas(){
     return "Jugos disponibles: "+mora+fresa+mango+piña;
    }
    
}
