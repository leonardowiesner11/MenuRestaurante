
package restaurante.Componente.bebida;


public abstract class Licores extends Bebida{
    @Override
    public abstract String guardar();
    public String BBC;
    public String ClubColombia;
    public String Corona;
    public String Heineken;
    public String Redds;
    
    public Licores (String BBC, String ClubColombia, String Corona, String Heineken, String Redds){
     this.BBC=BBC;
     this.ClubColombia=ClubColombia;
     this.Corona=Corona;
     this.Heineken=Heineken;
     this.Redds=Redds;        
    }
    
    public String mostrarGaseosas(){
     return "Licores disponibles: "+BBC+ClubColombia+Corona+Heineken+Redds;
    }
    
}
